# Installation, from a clean machine

`apc_prop.py` needs **nothing but Python** to run. Three optional packages make
the output better, and one of them, cadquery, is the difference between a STEP
file you can use in SolidWorks and one you cannot. Install them if you can.

## 1. Python

You need Python 3.8 or newer. 3.11 or 3.12 are the safest choices, because
cadquery lags the newest release by a while.

**Windows.** Install from [python.org](https://www.python.org/downloads/) and
tick **Add python.exe to PATH** on the first screen of the installer. Then open
a new PowerShell window and check it:

```powershell
python --version
```

If that prints nothing useful, try `py --version` and use `py` in place of
`python` everywhere below.

**macOS.** `brew install python@3.12`, or the python.org installer.

**Linux.** `sudo apt install python3 python3-venv python3-pip`, or your
distribution's equivalent.

## 2. A virtual environment

Optional, but it keeps these packages out of your system Python. Run this in
the folder holding your PE0 files.

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1          # Windows PowerShell
```

```bash
python3 -m venv .venv
source .venv/bin/activate            # macOS / Linux
```

If PowerShell refuses to run the activate script, either allow it for this
session with `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, or
skip the virtual environment and call `.venv\Scripts\python.exe` directly.

## 3. The optional packages

```powershell
python -m pip install --upgrade pip
python -m pip install numpy manifold3d cadquery
```

What each one buys you:

| Package | Without it | With it |
|---|---|---|
| `numpy` + `manifold3d` | blades and hub are separate overlapping shells | one watertight solid, bore cut properly |
| `cadquery` | STEP is a faceted approximation, thousands of flat facets | STEP is a true NURBS solid, one body, CAD-ready |

`cadquery` is a large install, a few hundred megabytes, because it brings
OpenCascade with it. Give it a few minutes. If it refuses to install, the usual
reason is a Python version it does not yet support: make a 3.12 environment and
try again.

## 4. Confirm

```powershell
python apc_prop.py --check
```

You want to see:

```
  solid fusion : yes (numpy + manifold3d)
  STEP quality : NURBS B-rep (cadquery)
```

Anything else still runs, it just produces a worse model, and the script tells
you which part is degraded rather than failing quietly.

## Notes for a locked-down machine

The script itself needs no network access at any point. The aerofoil
coordinates it uses are embedded in the file, so it works entirely offline once
Python is present. Everything is written to the folder you run it in; nothing is
installed, registered or cached elsewhere.
