# APC propeller geometry to 3D model

`apc_prop.py` reads an APC propeller geometry file and writes a solid model of
that propeller: STL, OBJ, STEP and a self-contained HTML viewer. It is a single
file with no required dependencies.

- **INSTALL.md** — setting up from a clean machine.
- **PE0_file_guide.docx** — what every column in a PE0 file means, and how to
  draw the blade yourself, worked through on the 8x8E. Read this if you want to
  understand the data rather than just convert it.
- **apc_prop.py** — the converter.
- **8x8E-PERF.PE0**, **7x9E-PERF.PE0** — two inputs to try it on.

## Quick start

```powershell
python apc_prop.py --check              # what this machine can do
python apc_prop.py 8x8E-PERF.PE0        # one propeller
python apc_prop.py . STEP_FILES         # a whole folder of PE0 files
```

One propeller writes four files: `APC_8x8E.stl`, `.obj`, `.step` and `.html`.
Open the HTML in any browser to spin the model and read the per-station
comparison against the source file, which is the quickest way to judge a result.

Folder mode takes the input folder as the first argument and the output folder
as the second. Add `--resume` to skip propellers already written, so an
interrupted batch can be restarted.

## Options

| Option | Effect |
|---|---|
| `--formats=stl,step` | write only these, of `stl`, `obj`, `step`, `html` |
| `--check` | report the optional packages found, then stop |
| `--resume` | folder mode: skip propellers already written |
| `--split` | folder mode: one folder per propeller, with a copy of its geometry file in it |
| `--bore=5mm` | bore diameter, overriding the guess |
| `--hub-thickness=10mm` | hub disc thickness, overriding the file |
| `--step-ruled` | loft the STEP as many small patches rather than one spline surface per blade side |
| `--root-blend=2.0` | radius, mm, for a fillet where the blade leaves the hub's top face |
| `--mesh=SEC,PTS` | mesh density, spanwise and per surface (default 140,51) |
| `--step=SEC,PTS` | the same for the STEP loft (default 56,41) |

Both length options accept `mm`, `cm` or `in`, and a bare number is read as
inches, the unit the file itself uses. So `--hub-thickness=10mm` and
`--hub-thickness=0.3937` are the same thing, and the build echoes the value it
used in both units with `(set)` or `(file)` beside it, so a mistake is visible
in the first three lines of output.

The bore is worth setting per model: there is no bore column in the file, so the
script guesses from hub size, and a 7x9E for example is really 5 mm
(`--bore=5mm`) where the guess picks 1/4 in.

## Two kinds of file in APC's archive

Most files describe a whole propeller: a hub with blades on it. Eighteen do
not. They carry no HUBRAD and their station table starts at HUBTRA, which is
how APC supply a folding blade, since its hub is a separate part. For those the
script writes a single blade capped at its root, with no hub and no bore, and
says so in the build summary. They are the F and MRF models plus the 15x12E.

The table itself comes in three layouts, and the columns are read by name for
that reason rather than by counting them. The usual layout has fourteen columns
including RAKE(Z); the folding files have thirteen and no RAKE at all, which for
a flat parting line means zero; the 15x12E has fourteen that are not the usual
fourteen, with no RAKE and a trailing PITCH(REAL). Counting columns reads that
last one as the usual layout shifted by one, which puts its twist into the
thickness ratio and makes the model several times too heavy with nothing
looking wrong.

## What the model reproduces

Every propeller is built from the file's own columns, and two of them are used
as fit targets so the result is not merely plausible but numerically right.

| Quantity | Source | Agreement on the 8x8E |
|---|---|---|
| Section area | fitted to CROSS-SECTION | within 0.4% at every station |
| Section camber | fitted to CG(Y), CG(Z) | comes out near 5% of chord all along |
| ZHIGH | not fitted, used as a check | within 0.006 in |
| Hub disc | CHORD, MAX-THICK, ZHIGH at r=0 | 0.800 x 0.347 in, top face at 0.100 in |
| Overall depth at the hub | consequence of the above | 0.401 in against APC's published 0.40 |
| Total volume | consequence of the above | 0.500 against 0.546 in³, 8% light |

The thickness and camber are fitted separately because each column depends on
one of them alone: area is set by thickness, and the centroid's height above the
chord line by camber. Tying camber to THICKNESS RATIO, which is the obvious
thing to do and what an earlier version of this script did, gives a root
cambered three times as hard as the tip and a visibly negative angle of attack
near the hub.

ZHIGH is deliberately not a fit target. On a steeply pitched section the highest
point is the leading edge, where no camber change can reach it, so aiming at it
distorts the whole section. Leaving it out makes it a real check, and it lands
within 0.006 in unaided.

## What it does not reproduce

**The moulded root fairing.** Inboard of HUBTRA the file's CROSS-SECTION is
about twice what an aerofoil of the quoted chord and thickness can hold. The
difference is the fillet where the blade swells into the hub, and no lofted
aerofoil section carries it. This is the whole of the volume shortfall: 8% on
the 8x8E and 25% on the 7x9E, all of it inside HUBTRA. Two things were tried
and rejected. Fattening the root sections to the tabulated area matches the
numbers but produces a lobed blob unlike the real part. Flooring the underside
of the root onto the plane of the hub face also matches, to a few per cent
across the whole root, but a plane is a plane and it shows as a flat panel with
a straight edge across the blend. What is left is the honest aerofoil, running
into the hub thinning as the table's chord and thickness ratio take it.

**The bore, and anything moulded.** No bore diameter, no adapter recess, no
hub rounding beyond a small rim radius, no lettering.

**The aerofoil blending law.** The file gives the two radii the transition runs
between but not how APC interpolate across it. A smoothstep blend of the camber
and thickness distributions is used here.

**Handedness.** Not inferred from the model name. Check the rotation convention
for your part before assuming the model matches it.

## Coordinates

X runs along the blade, Y is fore and aft in the plane of rotation, Z is along
the thrust axis. Rotation is right-handed about +Z, so the blade at +X moves
toward +Y and the leading edge is on the +Y side. The leading edge, which is the
mould parting line, sits at Y = SWEEP, Z = RAKE, and the chord line runs from it
inclined trailing-edge-down by TWIST. All output is in millimetres.

## STEP files and CAD

With cadquery installed the STEP is a true NURBS solid: one body, one shell,
tolerance 1e-06 mm or better. The build prints the tolerance it achieved and
refuses to call a file good above 1e-04 mm, because a body carrying loose
tolerances is one a CAD package will import with faults or refuse to knit.

If SolidWorks struggles with the default, try `--step-ruled`. The default builds
one spline surface per blade side, around 15 faces in total, which is the
smoothest body; the ruled variant builds several hundred small patches instead,
which some kernels prefer. Both are valid single solids.

## Licence and provenance

The geometry comes from APC's published Propeller Geometry Data files. This is a
documented reconstruction for layout and analysis work, not APC's manufacturing
CAD and not a validated replacement part. Aerodynamic, structural and
high-speed use need their own validation.
